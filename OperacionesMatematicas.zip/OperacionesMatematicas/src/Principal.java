import javax.swing.JOptionPane;

public class Principal {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Aplicacion miAPlicacion = new Aplicacion();
	}

}
